#' Install and Load Required Packages for RevolutionHtl
#' @export
install_revolutionhtl_deps <- function() {
  options(repos = c(CRAN = "https://cran.r-project.org"))

  # 1. Instalar BiocManager si falta
  if (!requireNamespace("BiocManager", quietly = TRUE)) {
    message("Installing BiocManager...")
    install.packages("BiocManager")
  }

  # 2. Lista de paquetes CRAN
  cran_packages <- c(
    "ggplot2", "dplyr", "tidyr", "RColorBrewer", "gridExtra",
    "cowplot", "magick", "here", "ggimage", "svglite", "ggfun",
    "ggnewscale", "patchwork", "yulab.utils", "tidytree", "scales",
    "lazyeval", "tidyselect", "gtable", "farver", "gridGraphics"
  )

  # 3. Lista de paquetes Bioconductor
  bioc_packages <- c("ggtree", "treeio", "ggtreeExtra", "phangorn", "aplot", "ggplotify")

  # 4. Función para instalar paquetes con manejo de errores
  install_packages_safely <- function(packages, bioc = FALSE) {
    for (pkg in packages) {
      if (!requireNamespace(pkg, quietly = TRUE)) {
        tryCatch({
          if (bioc) {
            BiocManager::install(pkg, ask = FALSE, update = FALSE)
          } else {
            install.packages(pkg)
          }
        }, error = function(e) {
          message("Error installing ", pkg, ": ", e$message)
        })
      }
    }
  }

  # 5. Instalar paquetes CRAN
  message("Instalando paquetes CRAN...")
  install_packages_safely(cran_packages)

  # 6. Instalar paquetes Bioconductor
  message("Instalando paquetes Bioconductor...")
  install_packages_safely(bioc_packages, bioc = TRUE)

  # 7. Cargar paquetes
  message("Cargando paquetes...")
  invisible(lapply(c(cran_packages, bioc_packages), function(pkg) {
    if (!require(pkg, character.only = TRUE)) {
      stop("No se pudo cargar el paquete: ", pkg)
    }
  }))
}
