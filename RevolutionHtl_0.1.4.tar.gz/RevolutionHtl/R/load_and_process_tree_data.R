#' Main function to load, process the tree, and execute subsequent modules
#'
#' This function is the entry point for the `RevolutionHtl` package. It takes a Newick tree file
#' and a reconciliation data file as inputs, processes the data, generates visualizations, and
#' saves the results. The function is modular, with each step handled by separate internal functions.
#'
#' @param newick_file Path to the Newick tree file (.nhx or .nwk format).
#' @param datos_file Path to the reconciliation data file (.tsv or .csv format).
#' @param header Logical. Indicates whether the reconciliation data file has a header row. Default is `TRUE`.
#'
#' @return This function does not return a value directly. It generates and saves plots in multiple
#'         formats (PDF, JPG, SVG) and prints the final plot to the console.
#'
#' @export
#'
#' @examples
#' \dontrun{
#' # Example usage with header:
#' Plot_tree("tl_project.labeled_species_tree.nhxx", "numbers_reconciliation.tsv", header = TRUE)
#'
#' # Example usage without header:
#' Plot_tree("tl_project.labeled_species_tree.nhxx", "numbers_reconciliation.tsv", header = FALSE)
#' }
Plot_tree <- function(newick_file, datos_file, header = TRUE) {
  # Step 1: Load and process the tree data
  # This step reads the Newick file and the additional data file, processes the tree, and generates the initial plot.
  result_step1 <- process_tree_data(newick_file, datos_file, header)
  tree <- result_step1$tree  # The processed phylogenetic tree
  p <- result_step1$plot     # The initial tree plot

  # Print or save the plot
  print(p)  # Display the initial tree plot

  # Step 2: Perform calculations and prepare data (Part 1)
  # This step calculates additional metrics (e.g., speciation, gains, losses) and merges the data with the tree.
  result_step2 <- process_calculations_part1(result_step1$tree_data_combined, tree)
  tree_data_with_all_parents <- result_step2$tree_data_with_all_parents  # Data with parent-child relationships
  heatmap_data_full <- result_step2$heatmap_data_full  # Data for the heatmap
  tree <- result_step2$tree  # Updated tree with merged data

  # Step 3: Perform calculations and prepare data (Part 2)
  # This step prepares the data for visualization, including heatmaps and dynamic plot limits.
  result_step3 <- process_calculations_part2(tree_data_with_all_parents, heatmap_data_full, tree)
  final_plot <- result_step3$final_plot  # The final tree plot with heatmaps
  combined_plots <- result_step3$combined_plots  # Combined plots for each node

  # Step 4: Create the bar plot
  # This step generates a bar plot showing changes in gene content (gains, losses, duplications).
  bar_plot_result <- process_bar_plot(result_step1$plot, result_step2$tree_data_with_all_parents)
  final_plot <- bar_plot_result$final_plot
  p_bar1 <- bar_plot_result$p_bar1
  print(final_plot)

  # Step 5: Add legends and save plots
  # This step adds legends to the final plot and saves it in multiple formats (PDF, JPG, SVG).
  combined_with_legends <- process_legends_and_save_plots(final_plot, heatmap_data_full)

  # Print or save the final plot
  print(combined_with_legends)  # Display the final plot with legends

  # Continue with other modules if needed
  # This section is a placeholder for additional modules that can be called if needed.
  if (!exists("in_devtools")) {
    # Call other modules here if necessary...
  }
}
